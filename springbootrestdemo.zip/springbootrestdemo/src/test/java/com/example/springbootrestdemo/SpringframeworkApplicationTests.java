package com.example.springbootrestdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringframeworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
