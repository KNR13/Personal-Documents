package com.example.springbootrestdemo.repository;

import com.example.springbootrestdemo.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository extends JpaRepository<Employee,Long> {
}
