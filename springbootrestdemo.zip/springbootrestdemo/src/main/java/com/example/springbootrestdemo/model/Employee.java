package com.example.springbootrestdemo.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Data;
import lombok.Generated;

import java.util.Date;

@Data
@Entity
@Table(name="employees")
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column(name="fisrt_name", nullable = false)
    @NotEmpty(message = "Employee Name should not be empty or null")
    @Size(min=3,max=15)
    private String firstName;
    @NotEmpty(message = "Employee last Name should not be empty or null")
    @Size(min=3,max=15)
    @Column(name="last_name",nullable = false)
    private String lastName;
    @NotEmpty(message = "Employee first Name should not be empty or null")
    @Column(name="email")
    private String email;

    @Column(name="age")
    @Positive
    @Digits(fraction = 0, integer = 10, message ="add a digit msg")
    @Min(value=18)
    @Max(value = 80)
    private int age;

    @Column(name="DOB")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
    private Date DOB;
}
